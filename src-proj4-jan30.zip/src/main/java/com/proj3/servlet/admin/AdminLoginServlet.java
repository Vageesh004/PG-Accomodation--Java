package com.proj3.servlet.admin;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.proj3.util.DBConnection;

@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Validation
        if (username == null || password == null ||
                username.trim().isEmpty() || password.trim().isEmpty()) {

            request.setAttribute("error", "Username and password are required");
            request.getRequestDispatcher("/views/admin/adminLogin.jsp")
                   .forward(request, response);
            return;
        }

        String sql = "SELECT adminId, username FROM admin WHERE username=? AND password=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // SUCCESS
                HttpSession session = request.getSession(true);
                session.setAttribute("adminId", rs.getInt("adminId"));
                session.setAttribute("adminUsername", rs.getString("username"));

                response.sendRedirect(request.getContextPath() + "/views/admin/admin_dashboard.jsp");
            } else {
                // FAILURE
                request.setAttribute("error", "Invalid username or password");
                request.getRequestDispatcher("/views/admin/adminLogin.jsp")
                       .forward(request, response);
            }

        } catch (SQLException e) {
            throw new ServletException("Database error during admin login", e);
        }
    }
}
