package com.proj3.servlet.users;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.proj3.util.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class UserLoginServlet
 */
@WebServlet("/UserLoginServlet")
public class UserLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public UserLoginServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		 String username = req.getParameter("username");
	        String password = req.getParameter("password");

	        try (Connection conn = DBConnection.getConnection()) {

	            PreparedStatement ps = conn.prepareStatement(
	                "SELECT user_id FROM users WHERE username=? AND password=?"
	            );
	            ps.setString(1, username);
	            ps.setString(2, password);

	            ResultSet rs = ps.executeQuery();

	            if (rs.next()) {
	                HttpSession session = req.getSession();
	                session.setAttribute("userId", rs.getInt("user_id"));
	                session.setAttribute("username", username);
	                
	                res.sendRedirect("views/users/user_dashboard.jsp");
	            } else {
	                res.sendRedirect("views/users/userLogin.jsp");
	            }

	        } catch (Exception e) {
	            e.printStackTrace();
	            res.sendRedirect("views/users/userLogin.jsp");
	        }
	   }
}


